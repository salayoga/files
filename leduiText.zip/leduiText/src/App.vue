<template>
  <div id="app">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive"></router-view>
    <van-tabbar v-model="$store.state.active" v-if="$route.meta.hasBottom">
      <van-tabbar-item name="home" to="/home" @click="handleChangeActive('home')">
        <span>首页</span>
        <img slot="icon" slot-scope="props" :src="props.active ? home.active : home.normal" />
      </van-tabbar-item>
      <van-tabbar-item name="charge" to="/charge" @click="handleChangeActive('charge')">
        <span>支付</span>
        <img slot="icon" slot-scope="props" :src="props.active ? charge.active : charge.normal" />
      </van-tabbar-item>
      <van-tabbar-item name="my" to="/my" @click="handleChangeActive('my')">
        <span>我的</span>
        <img slot="icon" slot-scope="props" :src="props.active ? my.active : my.normal" />
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
// import Storage from "@/api/Storage";
export default {
  name: "App",
  data() {
    return {
      active: "home",
      home: {
        normal: require("@/assets/images/tabbar_home_normal@2x.png"),
        active: require("@/assets/images/tarbar_home_selected@2x.png")
      },
      charge: {
        normal: require("@/assets/images/tabbar_pay_normal@2x.png"),
        active: require("@/assets/images/tarbar_pay_selected@2x.png")
      },
      my: {
        normal: require("@/assets/images/tabbar_my_normal@2x.png"),
        active: require("@/assets/images/tarbar_my_selected@2x.png")
      }
    };
  },
  methods: {
    handleChangeActive(active) {
      this.$store.commit("changeActive", active);
      // this.$storage.set("active", active);
    }
  },
  mounted() {
    if (this.$storage.get("active")) {
      this.active = this.$storage.get("active");
    }
  }
};
</script>

<style lang="less">
#app {
  font-size: 0.13rem;
  height: 100%;
  background: #f6f6f6;
  color: #333;
  box-sizing: border-box;
  overflow-y: scroll;
  .foot {
    position: fixed;
    left: 0;
    bottom: 0;
    right: 0;
  }
}
.van-nav-bar__arrow,
.van-nav-bar__text {
  color: #000 !important;
  font-size: 0.16rem;
}
.van-nav-bar__text {
  font-family: PingFang-SC-Bold;
}
.van-hairline--bottom {
  background: #f6f6f6;
}
.bk {
  background: url(./assets/images/icon_arrow@2x.png) right center no-repeat;
  background-size: 0.07rem auto;
}
.container {
  padding: 0 0.15rem;
  box-sizing: border-box;
  color: #333;
  // margin-bottom: 0.7rem;
  .form {
    border-radius: 0.15rem;
    background: #fff;
    padding: 0.15rem;
    margin-top: 0.15rem;
  }
  .submit {
    margin-top: 0.1rem;

    overflow: hidden;
    .btn {
      width: 100%;
      border-radius: 0.225rem;
      border: 0 !important;
      padding: 0;
    }
  }
}
.van-toast {
  z-index: 1000 !important;
}
input::-webkit-input-placeholder {
  color: #999 !important; /* WebKit browsers */
}

input:-moz-placeholder {
  color: #999 !important; /* Mozilla Firefox 4 to 18 */
}

input::-moz-placeholder {
  color: #999 !important; /* Mozilla Firefox 19+ */
}

input:-ms-input-placeholder {
  color: #999 !important; /* Internet Explorer 10+ */
}
//border.5px 边框
.border {
  position: relative;
  &:after {
    content: "";
    position: absolute;
    height: 1px;
    width: 100%;
    left: 0;
    bottom: 0;
    transform: scaleY(0.5);
    background: #ccc;
  }
}
.van-button--info {
  border: 0 !important;
}
.btnUnchoose {
  background: rgba(255, 255, 255, 0.6);
}
.btnChoose {
  background: rgba(255, 255, 255, 1);
}
input:-webkit-autofill {
  -webkit-box-shadow: 0 0 0px 1000px #fff inset !important; //设置input输入时的底色
  -webkit-text-fill-color: #333 !important; //设置自动为完后的文字颜色
  caret-color: #fff !important; //设置输入指针颜色
}
</style>

<template>
  <div>
    <van-nav-bar left-text="404" left-arrow @click-left="onClickLeft" />
    <img :src="require('@/assets/images/tips_404@2x.png')" alt />
  </div>
</template>

<script>
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>

<style lang="less" scoped>
img {
  display: block;
  width: 1.47rem;
  margin: 0.3rem auto;
}
</style>
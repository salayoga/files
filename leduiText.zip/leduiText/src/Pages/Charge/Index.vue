<template>
  <div class="index">
    <header class="head">支付</header>
    <div class="wallet">
      <div class="title">钱包余额(USDT_ERC20)</div>
      <div class="content">
        <img :src="require('@/assets/images/icon_yue@2x.png')" alt />
        <span>{{$store.state.money || this.$storage.get("money")}}</span>
      </div>
    </div>
    <div class="main">
      <div class="top">
        <div class="left">
          <div>
            <div class="title">接单额度（USDT_ERC20）</div>
            <div class="money">{{money}}</div>
          </div>
          <div>
            <div class="title">钱包余额（USDT_ERC20）</div>
            <div class="money">{{this.$store.state.money || this.$storage.get("money")}}</div>
          </div>
        </div>
        <div class="right">
          <img :src="qrcode" alt />
        </div>
      </div>
      <start></start>
    </div>
    <ul class="charge">
      <li @click="changeShow" :class="{'active':show}">正在执行</li>
      <li @click="changeShow" :class="{'active':!show}">历史接单</li>
    </ul>
    <div v-show="show">
      <my-charge
        :createtime="continueList.createtime | dataFormat('yyyy-MM-dd hh:mm:ss')"
        :order_sn="continueList.order_sn"
        :price="continueList.price"
      ></my-charge>
    </div>
    <div v-show="!show">
      <my-charge
        v-for="(item,index) of completeList"
        :key="index"
        :createtime="item.createtime | dataFormat('yyyy-MM-dd hh:mm:ss')"
        :order_sn="item.order_sn"
        :price="item.price"
      ></my-charge>
    </div>
  </div>
</template>

<script>
import Start from "@/components/start";
import MyCharge from "@/components/Charge";
export default {
  data() {
    return {
      show: true,
      continueList: {},
      completeList: [],
      money: 0,
      qrcode: ""
    };
  },
  components: {
    Start,
    MyCharge
  },
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/order/user_orders?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.continueList = data.continue || {};
        this.completeList = data.complete;
      })
      .catch();
    this.$http
      .post(
        this.$baseUrl +
          "/api/order/money?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        let data = res.data.data;
        this.money = data.edu;
      });
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/get_biaddress?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.qrcode = data.qrcode;
      })
      .catch();
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/getYue?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        let data = res.data;
        this.$store.commit("changeMoney", data.data);
      });
  },
  methods: {
    changeShow() {
      this.show = !this.show;
    },
    changeTime(time) {
      time = Number(time * 1000) + "";
      let year = time.getFullYear();
      let month = time.getMonth() + 1;
      let day = time.getDate();
      let hour = time.getHours();
      let minute = time.getMinute();
      let second = time.getSeconds();
      return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    }
  },
  filters: {
    dataFormat(value, fmt) {
      let getDate = new Date(value * 1000);
      let o = {
        "M+": getDate.getMonth() + 1,
        "d+": getDate.getDate(),
        "h+": getDate.getHours(),
        "m+": getDate.getMinutes(),
        "s+": getDate.getSeconds(),
        "q+": Math.floor((getDate.getMonth() + 3) / 3),
        S: getDate.getMilliseconds()
      };
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(
          RegExp.$1,
          (getDate.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (let k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
          fmt = fmt.replace(
            RegExp.$1,
            RegExp.$1.length === 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return fmt;
    }
  }
};
</script>

<style lang="less" scoped>
.index {
  padding: 0 0.15rem;
  background: #f5f5f5;
  height: 100%;
  .head {
    padding: 0.15rem 0;
    font-family: PingFang-SC-Bold;
    font-size: 0.15rem;
  }
  .wallet {
    height: 1.5rem;
    border-radius: 0.15rem;
    background: url(../../assets/images/bgd_person@2x.png) no-repeat;
    background-size: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    font-family: PingFang-SC-Regular;
    padding: 0.25rem 0 0.1rem;
    color: #fff;
    box-sizing: border-box;
    .title {
      font-size: 0.13rem;
      margin-bottom: 0.36rem;
    }
    .content {
      font-size: 0.25rem;
      font-family: PingFang-SC-Bold;
      img {
        margin-right: 0.1rem;
        width: 0.14rem;
      }
    }
  }
  .main {
    height: 2rem;
    padding: 0.15rem;
    box-sizing: border-box;
    background: #fff;
    border-radius: 0.15rem;
    margin-top: 0.15rem;
    .top {
      display: flex;
      justify-content: space-between;
      .left {
        height: 1.24rem;
        flex: 1;
        > div {
          border-bottom: 1px solid #ccc;
          height: 0.62rem;
          display: flex;
          flex-direction: column;
          .title {
            font-size: 0.13rem;
            color: #333;
            font-size: 0.13rem;
            height: 0.13rem;
            margin-top: 0.1rem;
            color: #333;
          }
          .money {
            font-size: 0.17rem;
            height: 0.43rem;
            line-height: 0.43rem;
          }
        }
      }
      .right {
        margin-left: 0.15rem;
        img {
          width: 1.24rem;
          height: 1.24rem;
        }
      }
    }
  }
  .charge {
    display: flex;
    flex-direction: row;

    li {
      flex: 1;
      text-align: center;
      padding: 0.1rem 0;
      cursor: pointer;
    }
  }
}
.active {
  color: #4973ff;
  position: relative;
  &:before {
    content: "";
    position: absolute;
    bottom: 0;
    width: 25%;
    transform: translateX(-50%);
    left: 50%;
    height: 1px;
    background: #4973ff;
  }
}
</style>
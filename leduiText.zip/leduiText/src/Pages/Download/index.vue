<template>
  <div class="download">
    <img class="img" :src="logo" alt />
    <div class="link">
      <div>
        <a
          class="ios"
          href="itms-services://?action=download-manifest&url=https://admin.fqwlkj.com.cn/manifest.plist"
        >IOS下载</a>
      </div>
      <div>
        <a class="android" href="/qqld.apk">Android下载</a>
      </div>
    </div>
    <div class="bottom">
      <img :src="require('@/assets/images/bgd_dowanload@2x.png')" alt />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      logo: require("@/assets/images/logo_login@2x.png")
    };
  }
};
</script>

<style lang="less" scoped>
.download {
  background: linear-gradient(
    0deg,
    rgba(71, 115, 255, 1) 0%,
    rgba(103, 139, 255, 1) 100%
  );
  position: relative;
  box-sizing: border-box;
  padding-top: 0.6rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  .img {
    height: 0.6rem;
  }
  .link {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2;
    div {
      width: 2rem;
      height: 0.4rem;
      line-height: 0.4rem;
      border-radius: 0.05rem;
      background: #fff;
      text-align: center;
      a {
        display: block;
        width: 100%;
        height: 100%;
        color: #4873ff;
        font-size: 0.14rem;
      }
      .android {
        background: url(../../assets/images/icon_android@2x.png) 0.25rem center
          no-repeat;
        background-size: 0.17rem auto;
        margin-top: 0.3rem;
        z-index: 2;
      }
      .ios {
        background: url(../../assets/images/icon_ios@2x.png) 0.25rem center
          no-repeat;
        background-size: 0.17rem auto;
      }
    }
  }
  .bottom {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
  }
}
</style>
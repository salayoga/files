<template>
  <div class="forget">
    <van-nav-bar left-text="忘记密码" left-arrow @click-left="onClickLeft" />
    <div class="inputGroup">
      <div class="border">
        <div>手机号</div>
        <input type="text" placeholder="请输入手机号" v-model="phone" />
      </div>
      <div>
        <div>验证码</div>
        <input type="text" placeholder="请输入验证码" v-model="code" />
        <button @click="getcode" :disabled="bool">{{content}}</button>
      </div>
    </div>
    <div class="inputGroup2">
      <div class="border">
        <div>密码</div>
        <input type="password" placeholder="请输入密码" v-model="password" />
      </div>
      <div>
        <div>确认密码</div>
        <input type="password" placeholder="请再次输入密码" v-model="passwordAgain" />
      </div>
    </div>
    <div class="submit">
      <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank, checkPsw, checkPhone, changeParams } from "@/api/form";
import { getCode } from "@/api/form";
import qs from "qs";
import md5 from "md5";
export default {
  data() {
    return {
      code: "",
      phone: "",
      password: "",
      passwordAgain: "",
      bool: false,
      content: "获取验证码",
      btnSubmit: false
    };
  },
  components: {
    MyInput
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    getcode() {
      if (getCode(this.phone)) {
        this.bool = true;
        this.content = 60;
      }
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([
          this.phone,
          this.code,
          this.password,
          this.passwordAgain
        ]) ||
        checkPsw(this.passwordAgain, this.password) ||
        checkPhone(this.phone)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/public/forgetpwd?user_token=" +
            this.$storage.get("token"),

          qs.stringify({
            mobile: this.phone,
            mobile_code: this.code,
            password: this.password,
            re_password: this.passwordAgain
          })
        )
        .then(res => {
          console.log(res);
          const data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  watch: {
    content(newValue) {
      if (newValue == 60) {
        let timer = setInterval(() => {
          this.content = --newValue;
          if (this.content == 0) {
            clearInterval(timer);
            this.content = "获取验证码";
            this.bool = false;
          }
        }, 1000);
      }
    }
  }
};
</script>

<style lang="less">
.forget {
  height: 100%;
  background: #f6f6f6;

  .inputGroup,
  .inputGroup2 {
    margin: 0 0.16rem;
    margin-top: 0.3rem;
    border-radius: 0.05rem;
    padding: 0 0.1rem;
    background: #fff;
    > div {
      display: flex;
      flex-direction: row;
      height: 0.47rem;
      align-items: center;
      > div {
        width: 0.7rem;
      }
      input {
        flex: 1;
      }
    }
    button {
      padding: 0.05rem 0.12rem;
      min-width: 1rem;
      background: #1989fa;
      color: #fff;
      border-radius: 0.05rem;
    }
  }
  .inputGroup2 {
    margin-top: 0.1rem;
  }
  .submit {
    padding: 0 0.16rem;
    margin-top: 0.1rem;

    overflow: hidden;
    .btn {
      width: 100%;
      border-radius: 0.225rem;
    }
  }
}
</style>
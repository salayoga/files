<template>
  <div class="home">
    <my-cover :show="show" @funcCover="handleChangeShow"></my-cover>

    <div class="cover">
      <header class="head">
        <div class="head-left">
          <div class="img" style="border-radius: 50%;">
            <img class="myImg" :src="$store.state.photo" alt />
          </div>

          <div>
            <div class="top">
              {{$store.state.name}}
              <span v-show="this.$store.state.showStatus">(已激活)</span>
            </div>
            <div class="bottom">{{$store.state.phone}}</div>
          </div>
        </div>
        <div class="head-right" @click="handlechangejh" v-show="!this.$store.state.showStatus">激活</div>
      </header>
      <div class="wallet">
        <div class="title">钱包余额(USDT_ERC20)</div>
        <div class="content">
          <img :src="require('@/assets/images/icon_yue@2x.png')" alt />
          <span>{{$store.state.money || this.$storage.get("money")|| 0}}</span>
        </div>
        <ul class="bottom">
          <router-link tag="li" to="/invest">
            <img :src="require('@/assets/images/icon_cz@2x.png')" alt />
            <p>充币</p>
          </router-link>
          <router-link tag="li" to="/withdraw">
            <img :src="require('@/assets/images/icon_tx@2x.png')" alt />
            <p>提币</p>
          </router-link>
          <router-link tag="li" to="/transfer">
            <img :src="require('@/assets/images/icon_zz@2x.png')" alt />
            <p>转账</p>
          </router-link>
        </ul>
      </div>
      <div class="swiper">
        <start></start>
        <div class="swiper-content">
          <div class="swiper-content-title">
            <img :src="require('@/assets/images/icon_tongzhi@2x.png')" alt />
            <div>累计已有{{num}}人次公排</div>
          </div>
          <div class="ul-cover">
            <vue-seamless-scroll :data="liList" :class-option="classOption" class="table-content">
              <ul class="swiper-content-liList">
                <li v-for="(item,index) of liList" :key="index">
                  <div class="liImg" style="border-radius: 50%;">
                    <img class="myliImg" :src="item.avatar" />
                  </div>
                  <div class="first">{{item.mobile}}接单</div>
                  <div>{{item.price}}</div>
                  <div>USDT_ERC20</div>
                </li>
              </ul>
            </vue-seamless-scroll>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Start from "@/components/start";
import myCover from "@/components/cover";
import Storage from "@/api/Storage.js";
export default {
  data() {
    return {
      photo: require("@/assets/images/userhead@2x.png"),
      name: "",
      tel: "",
      liList: [],
      num: 0,
      show: true,
      isLoading: false,
      showStatus: false
    };
  },
  components: {
    Start,
    myCover
  },
  props: {},
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/info?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;

        this.$store.commit("changePhone", data.mobile);

        this.$store.commit("changeName", data.username);

        this.liList = data.list || [];

        this.num = data.order_num;

        this.$store.commit("changeGain", data.number);

        this.$store.commit("changePhoto", data.avatar);

        this.$store.commit("changeMoney", data.money);

        this.$storage.set("phone", data.mobile);
        if (!this.$storage.get("status")) {
          this.$storage.set("status", parseInt(data.status));
        }
        if (this.$storage.get("status") == 1) {
          this.show = false;
        }
        if (data.status == 1) {
          this.$store.commit("changeShowStatus", true);
        } else {
          this.$store.commit("changeShowStatus", false);
        }
      })
      .catch(res => {});
  },
  activated() {
    if (this.$storage.get("status") == 1) {
      this.show = false;
    }
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/getYue?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        let data = res.data;
        this.$store.commit("changeMoney", data.data);
      });
  },
  methods: {
    handleChangeShow() {
      this.show = false;
      this.$storage.set("status", 1);
    },
    handlechangejh() {
      this.show = true;
    },
    onRefresh() {
      setTimeout(() => {
        this.$toast("刷新成功");
        this.isLoading = false;
        location.reload();
      }, 500);
    }
  },
  computed: {
    classOption() {
      return {
        waitTime: 2000,
        step: 0.5,
        hoverStop: false
      };
    }
  }
};
</script>

<style lang="less" scoped>
.home {
  background: #f4f4f4;
  overflow-y: hidden;
  height: 100%;
  position: relative;
  .cover {
    padding: 0.15rem;
    .head {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.12rem;
      .head-left {
        display: flex;
        flex-direction: row;
        .img {
          width: 0.4rem;
          height: 0.4rem;
          margin-right: 0.1rem;
          overflow: hidden;
          .myImg {
            width: 100%;
            height: 100%;
          }
        }
        > div {
          .top {
            font-size: 0.14rem;
            color: #000;
          }
          .bottom {
            color: #999;
            font-size: 0.1rem;
          }
        }
      }
      .head-right {
        background-size: 100%;
        position: relative;
        .head-right-i {
          width: 0.14rem;
          height: 0.14rem;
          line-height: 0.14rem;
          text-align: center;
          position: absolute;
          left: 0.14rem;
          top: -0.08rem;
          background: #e93b3d;
          color: #fff;
          border-radius: 50%;
        }
      }
    }
    .wallet {
      height: 2rem;
      background: url(../../assets/images/bgd_home@2x.png) no-repeat;
      background-size: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      align-items: center;
      text-align: center;
      font-family: PingFang-SC-Regular;
      padding: 0.25rem 0 0.1rem;
      color: #fff;
      box-sizing: border-box;
      .title {
        font-size: 0.13rem;
      }
      .content {
        font-size: 0.25rem;
        font-family: PingFang-SC-Bold;
        img {
          margin-right: 0.1rem;
          width: 0.14rem;
        }
      }
      .bottom {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        width: 100%;
        li {
          img {
            width: 0.36rem;
            margin-bottom: 0.05rem;
          }
        }
      }
    }
    .liList {
      padding: 0 0.15rem;
      background: #fff;
      border-radius: 0.1rem;
      font-size: 0.13rem;
      margin: 0.1rem 0;
      > div:first-child {
        border-bottom: 1px solid #ccc;
      }
      > div {
        display: flex;
        justify-content: space-between;
        height: 0.49rem;
        align-items: center;
        overflow: hidden;

        img {
          width: 0.3rem;
          height: 0.3rem;
        }
      }
    }
  }
  .swiper {
    border-radius: 0.3rem 0.3rem 0 0;
    background: #fff;
    padding: 0 0.15rem;
    box-sizing: border-box;
    width: 100%;
    margin-top: 0.15rem;

    .swiper-content {
      border-top: 1px solid #ccc;
      .swiper-content-title {
        height: 0.35rem;
        line-height: 0.35rem;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #4974ff;
        img {
          width: 0.15rem;
          height: 0.15rem;
          margin-right: 0.1rem;
        }
      }
      .ul-cover {
        overflow: hidden;
        position: relative;
        width: 100%;
      }
      .swiper-content-liList {
        li {
          background: #f6f6f6;
          border-radius: 0.06rem;
          margin-bottom: 0.1rem;
          height: 0.5rem;
          display: flex;
          align-items: center;
          .liImg {
            width: 0.3rem;
            height: 0.3rem;
            margin: 0.1rem;
            overflow: hidden;
            .myliImg {
              width: 100%;
              height: 100%;
            }
          }
          div {
            margin-right: 0.1rem;
            color: #666;
          }
          .first {
            color: #000;
          }
        }
      }
    }
  }
}
</style>
<template>
  <div class="invest">
    <van-nav-bar left-text="充币" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="title">扫描下方二维码进行充币</div>
      <div class="cover">
        <img :src="imgUrl" alt />
        <div class="address">充币地址(币类型:USDT_ERC20)</div>
        <div class="code" v-html="address"></div>
        <button
          data-clipboard-action="copy"
          class="btn cobyDomObj"
          :data-clipboard-text="address"
          @click="copyLink"
        >复制钱包地址</button>
        <!-- <button class="btn" @click="copyBtn">复制钱包地址</button> -->
      </div>
      <div class="descript">
        <p>请勿向上述地址充币任何非ERC20_USDT资产,否则资产将不可找回</p>
        <p>你充币至上述地址后，需要整个网络节点的确认,12次网络确认后到账,12次网络确认后可提币。</p>
        <p>最小充币金额:1USDT_ERC20,小于最小金额的充币将不会上账且无法退回。</p>
        <p>你的充币地址不会经常改变,可以重复充币:如果更改,我们会劲量通过网站公告或邮件通知你。</p>
        <p>请务必确认电脑及浏览器安全,防止信息被篡改或泄露。</p>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank } from "@/api/form";
export default {
  data() {
    return {
      num: 0,
      imgUrl: "",
      address: ""
    };
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    copyLink() {
      let _this = this;
      let clipboardObj = new this.clipboard(".cobyDomObj");
      clipboardObj.on("success", function() {
        _this.$toast("复制成功");
      });
      clipboardObj.on("error", function() {
        _this.$toast("复制失败");
      });
    }
  },
  components: {
    MyInput
  },
  created() {
    this.$storage.set("status", "1");
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/get_biaddress?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.address = data.address;
        this.imgUrl = data.qrcode;
      })
      .catch();
  }
};
</script>

<style lang="less" scoped>
.invest {
  margin-bottom: 0.5rem;
}
.container {
  margin-top: 0.2rem;
  .title {
    margin: 0.2rem auto;
    text-align: center;
  }
}
.cover {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  img {
    width: 1.8rem;
  }
  .address {
    margin-top: 0.4rem;
  }
  .code {
    margin-top: 0.2rem;
    text-align: center;
    word-break: break-all;
    white-space: wrap;
  }
  .btn {
    margin: 0.2rem;
    border-radius: 0.225rem;
    background: #4470ff;
    height: 0.45rem;
    line-height: 0.45rem;
    text-align: center;
    display: block;
    color: #fff;
    width: 100%;
  }
}
.descript {
  font-size: 0.1rem;
  line-height: 2;
  color: #999;
}
</style>
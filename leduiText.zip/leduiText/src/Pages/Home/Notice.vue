<template>
  <div class="notice">
    <van-nav-bar left-text="通知列表" left-arrow @click-left="onClickLeft" />
    <div class="listGroup">
      <div class="list">
        <div class="title">通知</div>
        <div class="time">2019-10-28 19:11:00</div>
        <div class="detail">你的会员已到期，请续费</div>
      </div>
      <div class="list">
        <div class="title">通知</div>
        <div class="time">2019-10-28 19:11:00</div>
        <div class="detail">你的会员已到期，请续费</div>
      </div>
      <div class="list">
        <div class="title">通知</div>
        <div class="time">2019-10-28 19:11:00</div>
        <div class="detail">你的会员已到期，请续费</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>

<style lang="less"  scoped>
.listGroup {
  margin: 0.15rem;
  .list {
    margin-bottom: 0.2rem;
    background: #fff;
    border-radius: 0.15rem;
    box-sizing: border-box;
    padding: 0.15rem;
    .title {
      font-size: 0.16rem;
    }
    .time {
      font-size: 0.1rem;
      margin: 0.1rem 0;
      color: #999;
    }
    .detail {
    }
  }
}
</style>
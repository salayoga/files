<template>
  <div class="pay">
    <van-nav-bar left-text="支付矿工费" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <my-input
          :label="'支付USDT_ERC20数量'"
          :placeholder="'10'"
          v-model="money"
          @input="getInput"
          :disabled="disabled"
        ></my-input>
        <my-input :label="'备注'" :placeholder="'矿工费'" v-model="deil" :disabled="disabled"></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank, checkMoney } from "@/api/form";
export default {
  data() {
    return {
      money: 10,
      deil: "矿工费",
      disabled: true,
      btnSubmit: false
    };
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    getInput(value) {
      this.money = value;
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (checkBlank([this.money, this.deil]) || checkMoney(this.money)) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/activat?user_token=" +
            this.$storage.get("token")
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 0) {
            this.$toast(data.msg);
          } else {
            this.$toast(data.msg);
            this.$store.commit("changeShowStatus", true);
            this.$store.commit(
              "changeMoney",
              this.$storage.get("money") - this.money
            );
            this.$router.go(-1);
          }
        });
    }
  },
  components: {
    MyInput
  },
  created() {
    this.$storage.set("status", "1");
  }
};
</script>

<style lang="less" scoped>
.pay {
}
</style>
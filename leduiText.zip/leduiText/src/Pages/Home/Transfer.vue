<template>
  <div class="transfer">
    <van-nav-bar left-text="转账" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <money></money>
      <div class="form">
        <my-input :label="'转账USDT_ERC20数量'" :placeholder="'请输入转账数量(一个起且整除1)'" v-model="num"></my-input>
        <my-input :label="'对方账号'" :placeholder="'请输入对方地址'" v-model="account"></my-input>
        <my-input
          :label="'二级密码'"
          :placeholder="'请输入二级密码'"
          v-model="password"
          :inputtype="'password'"
        ></my-input>
        <!-- <my-input
          :label="'验证码'"
          :placeholder="'请输入验证码'"
          v-model="code"
          :btn="btn"
          :tel="'13676843221'"
        ></my-input>-->
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import Money from "@/components/money";
import { checkBlank, checkMoney, changeParams } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([this.num, this.account, this.password, this.code]) ||
        checkMoney(this.num)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/sys/user_trans?user_token=" +
            this.$storage.get("token"),
          changeParams({
            money: this.num,
            address: this.account,
            erji_password: this.password,
            createtime: new Date().getTime()
          })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$store.commit(
              "changeMoney",
              this.$storage.get("money") - this.num
            );
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  components: {
    MyInput,
    Money
  },
  data() {
    return {
      num: "",
      account: "",
      password: "",
      btnSubmit: false
    };
  }
};
</script>

<style lang="less"  scoped>
.container {
  padding: 0 0.15rem;
  box-sizing: border-box;

  .form {
    border-radius: 0.15rem;
    background: #fff;
    padding: 0.15rem;
    margin-top: 0.15rem;
  }
  .submit {
    padding: 0 0.16rem;
    margin-top: 0.1rem;

    overflow: hidden;
    .btn {
      width: 100%;
      border-radius: 0.225rem;
    }
  }
}
</style>
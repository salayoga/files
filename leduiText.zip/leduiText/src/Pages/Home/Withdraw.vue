<template>
  <div class="invest">
    <van-nav-bar left-text="提币" left-arrow @click-left="onClickLeft" />

    <div class="container">
      <money :remark="'(提币手续费1%)'"></money>
      <div class="form">
        <my-input :label="'提币地址'" :placeholder="'请输入提币地址'" v-model="address"></my-input>
        <my-input :label="'提币数量'" :placeholder="'请输入提币数量'" v-model="num"></my-input>
        <my-input
          :label="'交易密码'"
          :placeholder="'请输入交易密码'"
          v-model="password"
          :inputtype="'password'"
        ></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提币</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank, checkMoney } from "@/api/form";
import Money from "@/components/money";
import qs from "qs";
export default {
  data() {
    return {
      num: 0,
      address: "",
      password: "",
      btnSubmit: false
    };
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([this.num, this.address, this.password]) ||
        checkMoney(this.num)
      ) {
        return;
      }

      this.$http
        .post(
          this.$baseUrl +
            "/api/sys/withdraw_bi?user_token=" +
            this.$storage.get("token"),
          qs.stringify({
            money: this.num,
            address: this.address,
            erji_password: this.password
          })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          const data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$store.commit(
              "changeMoney",
              this.$storage.get("money") - this.num
            );
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  components: {
    MyInput,
    Money
  }
};
</script>

<style lang="less"  scoped>
.all {
  color: #4470ff;
}
</style>
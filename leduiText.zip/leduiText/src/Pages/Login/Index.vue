<template>
  <div class="login">
    <div class="title">
      <img :src="require('@/assets/images/logo_login@2x.png')" alt />
    </div>
    <div class="inputGroup">
      <div class="inputDiv1 border">
        <select class="select">
          <option value disabled hidden selected>+86</option>
          <option value>+86</option>
        </select>
        <input type="text" placeholder="请输入手机号码" v-model="phone" />
        <i @click="delphone"></i>
      </div>
      <div class="inputDiv2 border">
        <div class="select">密码</div>
        <input placeholder="请输入6-16位密码" v-model="password" :type="show?'password':'text'" />
        <i @click="showpassword" :class="{showPassword:!show}"></i>
      </div>
      <div class="submit">
        <van-button
          :class="{'btn':true,'btnUnchoose':!choose,'btnChoose':choose}"
          type="info"
          @click="submit"
          :disabled="btnSubmit"
        >登录</van-button>
      </div>
      <div class="accountAndPsw">
        <div>
          <router-link to="/register">注册账号</router-link>
        </div>
        <div>
          <router-link to="/forget">忘记密码?</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { checkBlank, checkPhone, checkPswForm } from "@/api/form";
import qs from "qs";
export default {
  data() {
    return {
      phone: "",
      password: "",
      show: true,
      choose: false,
      btnSubmit: false
    };
  },
  mounted() {},
  watch: {
    phone() {
      if (this.phone && this.password) {
        this.choose = true;
        this.disabled = false;
      } else {
        this.choose = false;
        this.disabled = true;
      }
    },
    password() {
      if (this.phone && this.password) {
        this.disabled = false;
        this.choose = true;
      } else {
        this.disabled = true;
        this.choose = false;
      }
    }
  },
  methods: {
    delphone() {
      this.phone = "";
    },
    showpassword() {
      this.show = !this.show;
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([this.phone, this.password]) ||
        checkPhone(this.phone) ||
        checkPswForm(this.password)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl + "/api/public/login",
          qs.stringify({
            mobile: this.phone,
            password: this.password
          })
        )
        .then(res => {
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$storage.set("token", data.data);
            this.$storage.set("Flag", "isLogin");
            this.$router.push("/");
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  }
};
</script>

<style lang="less" scoped>
input:-webkit-autofill {
  -webkit-box-shadow: 0 0 0px 1000px #6c8fff inset !important; //设置input输入时的底色
  -webkit-text-fill-color: #fff !important; //设置自动为完后的文字颜色
  caret-color: #fff !important; //设置输入指针颜色
}
.login {
  height: 100%;
  box-sizing: border-box;
  padding-top: 0.76rem;
  background: #6c8fff;
  position: relative;
  .title {
    color: #333;
    font-size: 0.3rem;
    font-family: PangMenZhengDao;
    img {
      height: 0.6rem;
      margin-left: 0.4rem;
      z-index: 10;
    }
  }
  .inputGroup {
    margin: 0.4rem;
    color: #fff;
    .inputDiv1 {
      height: 50px;
      display: flex;
      color: #fff;
      margin-bottom: 0.1rem;
      align-items: center;
      select {
        width: 0.6rem;
        color: #fff;
      }
      input {
        flex: 1;
      }
      i {
        width: 0.1rem;
        height: 0.1rem;
        background: url(../../assets/images/close.png) no-repeat;
        background-size: 100%;
      }
    }
    .inputDiv2 {
      height: 50px;
      display: flex;
      color: #fff;
      align-items: center;
      .select {
        width: 0.6rem;
        color: #fff;
      }
      input {
        flex: 1;
      }
      i {
        width: 0.15rem;
        height: 0.15rem;
        background: url(../../assets/images/eye_off@2x.png) no-repeat;
        background-size: 100%;
      }
      .showPassword {
        width: 0.15rem;
        height: 0.15rem;
        background: url(../../assets/images/eye_on@2x.png) no-repeat;
        background-size: 100%;
      }
    }
  }

  .submit {
    margin-top: 0.4rem;
    .btn {
      width: 100%;
      height: 0.45rem;
      line-height: 0.45rem;
      border-radius: 0.225rem;
      color: #4571ff;
    }
  }
  .accountAndPsw {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin-top: 0.1rem;
    color: #fff;
    a {
      color: #fff;
    }
  }
  .bottom {
    position: absolute;
    height: 1.53rem;
    width: auto;
    bottom: 0;
    left: 0;
  }
}

.van-icon {
  width: 0.17rem;
  height: 0.17rem;
}
.van-cell {
  background: transparent;
}
input::-webkit-input-placeholder {
  color: #ddd !important; /* WebKit browsers */
}

input:-moz-placeholder {
  color: #ddd !important; /* Mozilla Firefox 4 to 18 */
}

input::-moz-placeholder {
  color: #ddd !important; /* Mozilla Firefox 19+ */
}

input:-ms-input-placeholder {
  color: #ddd !important; /* Internet Explorer 10+ */
}
</style>
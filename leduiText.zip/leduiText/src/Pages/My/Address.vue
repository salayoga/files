<template>
  <div class="address">
    <van-nav-bar left-text="修改提币地址" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <div class="content">
          USDT_ERC20钱包只能向USDT_ERC20地址发送资产，如果向非USDT_ERC20地址发送资产将不可找回。
          仅支持USDT_ERC20-ERC20的转出，
          请认真核实ERC20地址，确保无误后进行修改填写。
        </div>

        <my-input :label="'提币地址'" :placeholder="'请输入提币地址'" v-model="address"></my-input>
        <my-input
          :label="'二级密码'"
          :placeholder="'请输入二级密码'"
          v-model="password"
          :inputtype="'password'"
        ></my-input>
        <my-input :label="'验证码'" :placeholder="'请输入验证码'" v-model="code" :btn="btn" :tel="mytel"></my-input>
      </div>

      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank, checkPswForm } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([this.address, this.password, this.code]) ||
        checkPswForm(this.password)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/change_biaddress?user_token=" +
            this.$storage.get("token"),
          qs.stringify({
            biaddress: this.address,
            erji_password: this.password,
            mobile_code: this.code,
            mobile: this.$storage.get("phone")
          })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  components: {
    MyInput
  },
  data() {
    return {
      address: "",
      password: "",
      code: "",
      mytel: this.$storage.get("phone") + "",
      btn: true,
      btnSubmit: false
    };
  }
};
</script>

<style lang="less" scoped>
.content {
  border-bottom: 1px solid #eee;
  padding-bottom: 0.15rem;
  margin-bottom: 0.1rem;
}
</style>
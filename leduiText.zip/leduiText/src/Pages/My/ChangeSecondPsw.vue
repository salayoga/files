<template>
  <div>
    <van-nav-bar left-text="修改二级密码" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <my-input :label="'旧密码'" :placeholder="'请输入旧密码'" v-model="oldPsw" :inputtype="'password'"></my-input>
        <my-input :label="'二级密码'" :placeholder="'请输入二级密码'" v-model="psw" :inputtype="'password'"></my-input>
        <my-input
          :label="'确认二级密码'"
          :placeholder="'请再次输入二级密码'"
          v-model="pswAgain"
          :inputtype="'password'"
        ></my-input>
        <my-input :label="'验证码'" :placeholder="'请输入验证码'" v-model="code" :btn="btn" :tel="mobile"></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank, checkPsw } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([this.psw, this.pswAgain, this.code, this.oldPsw]) ||
        checkPsw(this.psw, this.pswAgain)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/change_erji_password?user_token=" +
            this.$storage.get("token"),
          qs.stringify({
            old_erji_password: this.oldPsw,
            erji_password: this.psw,
            re_erji_password: this.pswAgain,
            mobile_code: this.code,
            mobile: this.mobile
          })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  data() {
    return {
      oldPsw: "",
      psw: "",
      pswAgain: "",
      btn: true,
      mytel: "13676843221",
      code: "",
      mobile: this.$storage.get("phone") + "",
      btnSubmit: false
    };
  },
  components: {
    MyInput
  }
};
</script>

<style>
</style>
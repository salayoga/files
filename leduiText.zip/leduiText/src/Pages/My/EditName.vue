<template>
  <div>
    <van-nav-bar left-text="修改用户名" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <my-input :label="'修改用户名'" :placeholder="'请输入新的用户名'" v-model="name"></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (checkBlank([this.name])) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/change_username?user_token=" +
            this.$storage.get("token"),
          qs.stringify({ username: this.name })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$store.commit("changeName", this.name);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  data() {
    return {
      name: "",
      btnSubmit: false
    };
  },
  components: {
    MyInput
  }
};
</script>

<style lang="less" scoped>
.form {
  padding: 0.1rem 0.2rem;
  background: #f6f6f6;
}
</style>
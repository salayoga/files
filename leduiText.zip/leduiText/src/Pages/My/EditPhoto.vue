<template>
  <div>
    <van-nav-bar left-text="修改头像" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <van-uploader v-model="fileList" :max-count="1" :before-read="beforeRead" />
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import { checkBlank } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (checkBlank([this.fileList])) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/change_avatar?user_token=" +
            this.$storage.get("token"),
          qs.stringify({ file: this.fileList[0].content })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$store.commit("changePhoto", this.$baseUrl + data.data);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    },
    beforeRead(file) {
      if (file.type !== "image/jpeg") {
        this.$toast("请上传 jpg 格式图片");
        return false;
      }
      if (file.size > 1024 * 1024) {
        this.$toast("上传图片不能大于1M");
        return false;
      }
      return true;
    }
  },
  data() {
    return {
      fileList: [],
      btnSubmit: false
    };
  }
};
</script>

<style lang="less" scoped>
.form {
  padding: 0.2rem;
  display: flex;
  justify-content: center;
}
</style>
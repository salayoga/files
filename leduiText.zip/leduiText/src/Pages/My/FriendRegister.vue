<template>
  <div>
    <van-nav-bar left-text="好友注册" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <div>国籍</div>
        <my-select :selectList="countryList" @funcSelect="handleChangeSelect">
          <option value disabled selected hidden>请选择国籍</option>
        </my-select>
        <my-input :label="'手机号'" :placeholder="'请输入手机号作为注册号'" v-model="phone"></my-input>
        <my-input :label="'验证码'" :placeholder="'请输入验证码'" btn="btn" v-model="code" :tel="phone"></my-input>
        <my-input
          :label="'登录密码'"
          :placeholder="'请输入登录密码'"
          v-model="password"
          :inputtype="'password'"
        ></my-input>
        <my-input
          :label="'确认密码'"
          :placeholder="'请再次输入密码'"
          v-model="passwordAgain"
          :inputtype="'password'"
        ></my-input>
        <my-input
          :label="'二级密码'"
          :placeholder="'请输入二级密码'"
          v-model="secondpassword"
          :inputtype="'password'"
        ></my-input>
        <my-input
          :label="'再次输入二级密码'"
          :placeholder="'请再次输入二级密码'"
          v-model="secondpasswordAgain"
          :inputtype="'password'"
        ></my-input>
        <my-input :label="'用户昵称'" :placeholder="'请输入用户昵称'" v-model="nickname"></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import MyInput from "@/components/input";
import Money from "@/components/money";
import MySelect from "@/components/Select";
import { checkBlank, checkPhone, checkPsw, checkName } from "@/api/form";
import { myCountryList } from "@/api/define";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      let ckphone = checkPhone(this.phone);
      let ckpsw = checkPsw(this.password, this.passwordAgain);
      let Blank = checkBlank([
        this.selectValue,
        this.phone,
        this.code,
        this.password,
        this.passwordAgain,
        this.nickname,
        this.secondpassword,
        this.secondpasswordAgain
      ]);
      if (
        Blank ||
        ckphone ||
        ckpsw ||
        checkName(this.nickname) ||
        checkPsw(this.secondpassword, this.secondpasswordAgain)
      ) {
        return;
      }

      this.$http
        .post(
          this.$baseUrl +
            "/api/user/friend_reg?user_token=" +
            this.$storage.get("token"),
          qs.stringify({
            country: this.selectValue,
            mobile: this.phone,
            mobile_code: this.code,
            password: this.password,
            re_password: this.passwordAgain,
            username: this.nickname,
            erji_password: this.secondpassword,
            re_erji_password: this.secondpasswordAgain
          })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    },
    handleChangeSelect(value) {
      this.selectValue = value;
    }
  },
  data() {
    return {
      value1: 0,
      selectValue: "",
      btn: true,
      phone: "",
      code: "",
      password: "",
      passwordAgain: "",
      nickname: "",
      secondpassword: "",
      secondpasswordAgain: "",
      option1: [
        { text: "全部商品", value: 0 },
        { text: "新款商品", value: 1 },
        { text: "活动商品", value: 2 }
      ],
      countryList: myCountryList,
      btnSubmit: false
    };
  },
  components: {
    MyInput,
    Money,
    MySelect
  }
};
</script>

<style lang="less"  scoped>
.title {
  margin: 0 0.15rem;
  color: #333;
  font-size: 0.13rem;
  font-family: PingFang-SC-Regular;
}
.container {
  margin-bottom: 0.5rem;
}
</style>
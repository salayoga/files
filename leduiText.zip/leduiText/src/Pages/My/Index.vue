<template>
  <div class="index">
    <div class="top">
      <div class="info">
        <div class="info-content">
          <div class="photo" style="border-radius:50%;">
            <img class="photoImg" :src="$store.state.photo || this.$storage.get('photo')" alt />
          </div>

          <div class="info-content-name">
            <div class="info-content-name-top">
              {{$store.state.name || this.$storage.get("name")}}
              <span
                v-show="this.$store.state.showStatus"
              >(已激活)</span>
              <!-- <div class="info-content-name-span">5</div> -->
            </div>
            <div class="info-content-name-bom">{{$store.state.phone || this.$storage.get("phone")}}</div>
          </div>
        </div>
        <router-link class="edit" tag="div" to="/info"></router-link>
      </div>
    </div>
    <ul class="liList">
      <router-link tag="li" to="/team">
        <img class="img" :src="require('@/assets/images/icon_team@2x.png')" alt />
        <p>我的代理</p>
      </router-link>
      <router-link tag="li" to="/friendregister">
        <img class="img" :src="require('@/assets/images/icon_friends@2x.png')" alt />
        <p>好友注册</p>
      </router-link>
      <router-link tag="li" to="/message">
        <img class="img" :src="require('@/assets/images/icon_liuyan@2x.png')" alt />
        <p>留言反馈</p>
      </router-link>
    </ul>
    <div class="container">
      <div class="form">
        <list
          :border="item.border"
          v-for="(item,index) of urlList"
          :key="index"
          :url="item.url"
          :imgUrl="item.imgUrl"
          :content="item.content"
        ></list>
        <div class="myLink" @click="handleLogout">
          <img class="linkimg" :src="logout.imgUrl" alt />
          <div>{{logout.content}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import List from "@/components/Link";
export default {
  components: {
    List
  },
  data() {
    return {
      urlList: [
        {
          url: "/invite",
          imgUrl: require("@/assets/images/icon_invite@2x.png"),
          content: "邀请好友"
        },
        // {
        //   url: "/address",
        //   imgUrl: require("@/assets/images/icon_address@2x.png"),
        //   content: "收币地址"
        // },
        {
          url: "/wallet",
          imgUrl: require("@/assets/images/icon_qianbao@2x.png"),
          content: "交易记录"
        },
        {
          url: "/problem",
          imgUrl: require("@/assets/images/icon_problem@2x.png"),
          content: "常见问题"
        },
        {
          url: "/changepsw",
          imgUrl: require("@/assets/images/icon_password@2x.png"),
          content: "修改登录密码"
        },
        {
          url: "/changesecondpsw",
          imgUrl: require("@/assets/images/icon_2password@2x.png"),
          content: "修改二级密码"
        }
      ],
      logout: {
        imgUrl: require("@/assets/images/icon_change@2x.png"),
        content: "更换账号"
      }
    };
  },
  methods: {
    handleLogout() {
      this.$storage.clear();
      this.$router.push("/login");
      location.reload();
    }
  }
};
</script>

<style lang="less" scoped>
.form {
  padding-top: 0;
  padding-bottom: 0;
  .myLink {
    display: flex;
    flex-direction: row;
    align-items: center;
    height: 0.5rem;
    border-bottom: 1px solid #eee;
    background: url(../../assets/images/icon_arrow@2x.png) right center
      no-repeat;
    background-size: auto 0.1rem;
    .linkimg {
      height: 0.24rem;

      margin-right: 0.2rem;
    }
  }
}
.top {
  height: 1.5rem;
  background: url(../../assets/images/bgd_person@2x.png) no-repeat;
  background-size: 100% 100%;
  padding: 0.15rem;
  box-sizing: border-box;
  .info {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    .info-content {
      display: flex;
      flex-direction: row;
      .info-content-name {
        margin-left: 0.15rem;
        color: #fff;
        .info-content-name-top {
          font-size: 0.15rem;
          margin-bottom: 0.1rem;
          display: flex;
        }
        .info-content-name-span {
          margin-left: 0.02rem;
          width: 0.2rem;
          height: 0.2rem;
          background: url(../../assets/images/icon_VIP@2x.png) top center
            no-repeat;
          background-size: 0.18rem;
          color: #ff9d02;
          text-align: center;
          line-height: 0.3rem;
        }
      }
    }
  }
  .photo {
    width: 0.65rem;
    height: 0.65rem;
    overflow: hidden;
    .photoImg {
      width: 100%;
      height: 100%;
    }
  }
  .edit {
    width: 0.18rem;
    height: 0.18rem;
    background: url(../../assets/images/icon_edit@2x.png) no-repeat;
    background-size: 100%;
  }
}
.liList {
  display: flex;
  margin: 0.2rem 0.15rem;
  margin-top: -0.2rem;
  background: #fff;
  border-radius: 0.15rem;
  height: 0.9rem;
  justify-content: space-around;
  align-items: center;
  li {
    .img {
      width: 0.4rem;
      height: auto;
      margin-bottom: 0.13rem;
    }
  }
}
</style>
<template>
  <div>
    <van-nav-bar left-text="基本资料" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <router-link to="/editphoto" class="bk" tag="div">
          <div class="img" style="border-radius:50%;">
            <img class="myImg" :src="this.$store.state.photo || this.$storage.get('photo')" alt />
          </div>
        </router-link>
        <router-link to="/editname" class="bk" tag="div">
          <div>昵称</div>
          <div>{{this.$store.state.name || this.$storage.get("name")}}</div>
        </router-link>
        <Nav :content="infoList.content" :message="infoList.message" :show="infoList.show"></Nav>
      </div>
    </div>
  </div>
</template>

<script>
import Nav from "@/components/nav";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  },
  components: {
    Nav
  },
  data() {
    return {
      infoList: {
        content: "手机",
        message:
          this.$store.state.phone + "" || this.$storage.get("phone") + "",
        show: false
      }
    };
  }
};
</script>

<style lang="less" scoped>
.container {
  padding: 0 0.15rem;
  box-sizing: border-box;
  color: #333;

  .form {
    border-radius: 0.15rem;
    background: #fff;
    padding: 0 0.15rem;
    margin-top: 0.15rem;
  }
  .submit {
    padding: 0 0.16rem;
    margin-top: 0.1rem;

    overflow: hidden;
    .btn {
      width: 100%;
      border-radius: 0.225rem;
    }
  }
}
.img {
  width: 0.4rem;
  height: 0.4rem;
  overflow: hidden;

  .myImg {
    width: 100%;
    height: 100%;
  }
}
.bk {
  border-bottom: 1px solid #eee;
  height: 0.6rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-right: 0.2rem;
}
.nav:last-child {
  border: none;
}
</style>
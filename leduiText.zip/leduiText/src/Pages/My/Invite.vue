<template>
  <div>
    <van-nav-bar left-text="邀请好友" left-arrow @click-left="onClickLeft" />
    <div class="container">
      <div class="form">
        <img :src="imgUrl" alt />
        <div class="btn">
          <button
            data-clipboard-action="copy"
            class="cobyDomObj btn-left"
            :data-clipboard-text="address"
            @click="copyLink"
          >复制邀请码</button>
          <a :href="imgUrl" class="btn-right" download>保存邀请海报</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      imgUrl: "",
      address: ""
    };
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    copyBtn() {
      let copyText = this.$refs.code;
      copyText.select(); // 选择对象
      document.execCommand("Copy");
      this.$toast("复制成功");
    },
    copyLink() {
      let _this = this;
      let clipboardObj = new this.clipboard(".cobyDomObj");
      clipboardObj.on("success", function() {
        _this.$toast("复制成功");
      });
      clipboardObj.on("error", function() {
        _this.$toast("复制失败");
      });
    }
  },
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/my_qrcode?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        console.log(res);
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.imgUrl = data.qrcode;
        this.address = data.user_code;
      })
      .catch();
  }
};
</script>

<style lang="less" scoped>
.form {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #f6f6f6;
  margin-top: 0;
}
img {
  width: 3.35rem;
  margin-bottom: 0.2rem;
}
.btn {
  margin-top: 0.2rem;
  display: flex;
  justify-content: space-between;
  width: 100%;
  .btn-left,
  .btn-right {
    width: 1.3rem;
    height: 0.4rem;
    line-height: 0.4rem;
    background: #668aff;
    color: #fff;
    text-align: center;
    border-radius: 0.2rem;
  }
  .btn-right {
    background: #ffb94b;
  }
}
</style>
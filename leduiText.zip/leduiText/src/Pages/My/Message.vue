<template>
  <div>
    <van-nav-bar left-text="留言反馈" left-arrow @click-left="onClickLeft" />
    <router-link class="message" tag="div" to="/messageinfo">留言列表</router-link>
    <div class="friend">
      <!-- <div>问题类型</div>
      <my-select :selectList="selectList" @funcSelect="handleChangeSelect">
        <option value disabled selected hidden>意见或建议</option>
      </my-select>-->
      <textarea
        class="text"
        cols="30"
        rows="10"
        v-model="textarea"
        maxlength="50"
        placeholder="不超过五十个字"
      ></textarea>
      <!-- <van-uploader class="img" v-model="fileList" /> -->
    </div>
    <div class="submit">
      <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">提交</van-button>
    </div>
  </div>
</template>

<script>
import MySelect from "@/components/Select";
import { checkBlank } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    handleChangeSelect(value) {
      this.selectValue = value;
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (checkBlank([this.textarea])) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/guestbook?user_token=" +
            this.$storage.get("token"),
          qs.stringify({ content: this.textarea })
        )
        .then(res => {
          if (res.data.code == -1) {
            this.$toast("你的账号在他处登录");
            this.$storage.clear();
            this.$router.push("/login");
            location.reload();
          }
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            this.$router.go(-1);
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    }
  },
  data() {
    return {
      selectValue: "",
      textarea: "",
      fileList: [
        // Uploader 根据文件后缀来判断是否为图片文件
        // 如果图片 URL 中不包含类型信息，可以添加 isImage 标记来声明
      ],
      selectList: [
        { name: "信息咨询" },
        { name: "平台问题" },
        { name: "投诉举报" }
      ],
      btnSubmit: false
    };
  },
  components: {
    MySelect
  }
};
</script>

<style lang="less" scoped>
.message {
  padding: 0 0.12rem;
  position: absolute;
  right: 0;
  top: 0;
  height: 0.46rem;
  line-height: 0.46rem;
  z-index: 2;
  font-size: 0.16rem;
}
.friend {
  margin: 0.15rem;
  padding: 0.15rem;
  border-radius: 0.15rem;
  background: #fff;
  overflow: hidden;
}
.text {
  border: 1px solid #666;
  height: 1.5rem;
  border-radius: 0.05rem;
  width: 100%;
  padding: 0.1rem;
  box-sizing: border-box;
  word-break: break-all;
  white-space: wrap;
}
.img {
  margin-top: 0.1rem;
}
.submit {
  display: block;
  margin: 0.15rem;
  .btn {
    display: block;
    width: 100%;
    text-align: center;
    border-radius: 0.225rem;
  }
}
</style>
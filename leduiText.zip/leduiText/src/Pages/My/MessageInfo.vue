<template>
  <div class="notice">
    <van-nav-bar left-text="留言列表" left-arrow @click-left="onClickLeft" />
    <div class="listGroup">
      <div class="list" v-for="(item,index) of list" :key="index">
        <div class="time">{{item.createtime}}</div>
        <div class="detail">{{item.content}}</div>
        <div class="detail" v-if="item.reply">回复:{{item.reply}}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  },
  data() {
    return {
      list: ""
    };
  },
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/message_log?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.list = data;
      })
      .catch();
  }
};
</script>

<style lang="less"  scoped>
.listGroup {
  margin: 0.15rem;
  .list {
    margin-bottom: 0.2rem;
    background: #fff;
    border-radius: 0.15rem;
    box-sizing: border-box;
    padding: 0.15rem;
    .title {
      font-size: 0.16rem;
    }
    .time {
      font-size: 0.1rem;
      margin: 0.1rem 0;
      color: #999;
    }
    .detail {
    }
  }
}
</style>
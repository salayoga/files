<template>
  <div class="problem">
    <van-nav-bar left-text="常见问题" left-arrow @click-left="onClickLeft" />
    <div class="content">
      <van-collapse v-model="activeName" accordion>
        <van-collapse-item
          :title="item.title"
          :name="index+1"
          v-for="(item,index) of articleList"
          :key="index"
        >{{item.content}}</van-collapse-item>
      </van-collapse>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  },
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/questions?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;
        this.articleList = data;
      })
      .catch();
  },
  data() {
    return {
      activeName: "0",
      articleList: [
        {
          title: "如何充币？",
          content:
            "首页正上方点击充币−复制充币地址－前往钱包或交易所提币－选择USDT_ERC20/erc20代币－粘贴充币地址，确保地址无误后点提交，24小时均可充币，根据区块速度自动入账，到账会有提示音提示，也可在首页右上角的铃铛中查看！"
        },
        {
          title: "充币的资产安全吗？",
          content:
            "首页正上方点击充币−复制充币地址－前往钱包或交易所提币－选择USDT_ERC20/erc20代币－粘贴充币地址，确保地址无误后点提交，24小时均可充币，根据区块速度自动入账，到账会有提示音提示，也可在首页右上角的铃铛中查看！"
        },
        {
          title: "如何导出私钥备份？",
          content: "点击个人资料－导出keystore或助记词即可，并妥善保管。"
        },
        {
          title: "如何接单？",
          content:
            "最少接单额度为500～5000USDT_ERC20，24小时均可接单，根据你的充币数量在首页的正中间点击－马上接单－输入接单数量－输入二级密码－点提交即可！"
        },
        {
          title: "如何查看接单状态？",
          content:
            "接单成功点击首页正下方－支付－接单额度为0时，说明本轮接单已结束，接单本金+佣金已经返还到你的钱包余额中，此时可以开启下一轮的接单！"
        },
        {
          title: "如何提币？",
          content:
            "首页点击提现－输入数量－检查收币地址是否正确－输入二级密码后即可（100个USDT_ERC20起提）24小时均可提取，0矿工费，根据区块速度自动入账！并且提取成功后会有提示音提示，也可前往首页的右上角铃铛中查看！"
        },
        {
          title: "如何分享好友?",
          content:
            "首页点击邀请－复制您的分享链接或二维码－对方通过你的链接成功注册后，即分享成功，可在团队列表里查看该成员！新用户注册成功后需花费10USDT_ERC20矿工费激活该账号，可通过推荐人的转入USDT_ERC20激活或者自己充币，然后点击“马上接单”，会提示支付矿工费，支付成功后方可正常接单/分享！"
        }
      ]
    };
  }
};
</script>

<style lang="less" scoped>
.content {
  margin: 0 0.15rem;
  padding: 0 0.15rem;
  border-radius: 0.15rem;
  background: #fff;
  margin-top: 0.15rem;
}
</style>
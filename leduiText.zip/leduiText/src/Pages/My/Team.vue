<template>
  <div class="team">
    <van-nav-bar left-text="我的代理" left-arrow @click-left="onClickLeft" />
    <ul class="ul">
      <router-link tag="li" :to="{name:'TeamLeft'}">一级</router-link>
      <router-link tag="li" :to="{name:'TeamRight'}">代理</router-link>
    </ul>
    <div class="cover">
      <router-view />
    </div>
  </div>
</template>

<script>
import MyTeam from "@/components/tlist";
export default {
  data() {
    return {};
  },
  methods: {
    onClickLeft() {
      this.$router.push("/my");
    }
  },
  components: {
    MyTeam
  }
};
</script>

<style lang="less" scoped>
.team {
  .ul {
    display: flex;
    position: relative;
    li {
      background: #4571ff;
      height: 0.45rem;
      line-height: 0.45rem;
      flex: 1;
      text-align: center;
      font-size: 0.16rem;
      color: #fff;
    }
    &:after {
      content: "";
      width: 1px;
      height: 0.4rem;
      position: absolute;
      background: #fff;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }
  .cover {
    margin: 0.15rem;
  }
}
</style>
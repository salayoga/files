<template>
  <div>
    <div class="teamnum">一级人数:{{$store.state.zt}}</div>
    <my-team :teamList="teamList"></my-team>
  </div>
</template>

<script>
import MyTeam from "@/components/tlist";
export default {
  components: {
    MyTeam
  },
  created() {
    this.$http
      .get(
        this.$baseUrl +
          "/api/sys/user_zj?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;

        this.$store.commit("changezt", data.length);
        this.teamList = data;
      })
      .catch();
  },
  data() {
    return {
      teamList: []
    };
  }
};
</script>

<style lang="less" scoped>
.teamnum {
  font-size: 0.16rem;
  font-weight: bold;
}
</style>
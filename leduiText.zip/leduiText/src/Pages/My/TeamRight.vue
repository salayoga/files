<template>
  <div>
    <div class="teamnum">代理人数:{{$store.state.allt}}</div>
    <my-team :teamList="teamList"></my-team>
  </div>
</template>

<script>
import MyTeam from "@/components/tlist";
export default {
  components: {
    MyTeam
  },
  mounted() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/sys/user_team?user_token=" +
          this.$storage.get("token")
      )
      .then(res => {
        if (res.data.code == -1) {
          this.$toast("你的账号在他处登录");
          this.$storage.clear();
          this.$router.push("/login");
          location.reload();
        }
        let data = res.data.data;

        this.$store.commit("changeallt", data.length);
        this.teamList = data;
      });
  },
  data() {
    return {
      teamList: []
    };
  }
};
</script>

<style lang="less" scoped>
.teamnum {
  font-size: 0.16rem;
  font-weight: bold;
}
</style>
<template>
  <div>
    <van-nav-bar left-text="交易记录" left-arrow @click-left="onClickLeft" />
    <ul class="title-list">
      <li :class="{'active':show==1}" @click="changeStatus(1)">充值</li>
      <li :class="{'active':show==2}" @click="changeStatus(2)">提现</li>
      <li :class="{'active':show==3}" @click="changeStatus(3)">转账</li>
    </ul>
    <div class="listGroup">
      <div class="list border" v-for="(item,index) of list" :key="index">
        <div class="list-left">
          <div v-if="show==1">充值-充值到{{item.to_username}}</div>
          <div v-if="show==2">提现-提现到{{item.to_username}}</div>
          <div v-if="show==3">转账-转账给{{item.to_username}}</div>
          <div class="time">{{item.createtime}}</div>
        </div>
        <div class="list-right">{{item.money}}</div>
      </div>
    </div>
    <van-pagination
      class="page"
      v-if="total"
      v-model="currentPage"
      :show-page-size="3"
      :total-items="total"
      force-ellipses
      @change="handleChangePage"
    />
  </div>
</template>

<script>
import MyInput from "@/components/input";
import { checkBlank } from "@/api/form";
import qs from "qs";
export default {
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    changeStatus(index) {
      this.show = index;
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/user_log?user_token=" +
            this.$storage.get("token"),
          qs.stringify({ page: 1, type: this.show })
        )
        .then(res => {
          if (res.data.data) {
            let data = res.data.data;
            this.list = data.list;
            this.total = parseInt(data.count);
          } else {
            this.list = [];
            this.total = 0;
          }
        })
        .catch();
    },
    handleChangePage(page) {
      this.$http
        .post(
          this.$baseUrl +
            "/api/user/user_log?user_token=" +
            this.$storage.get("token"),
          qs.stringify({ page: page, type: this.show })
        )
        .then(res => {
          console.log(res);
          if (res.data.data) {
            let data = res.data.data;
            this.list = data.list;
            this.total = parseInt(data.count);
          } else {
            this.list = [];
            this.total = 0;
          }
        })
        .catch();
    }
  },
  created() {
    this.$http
      .post(
        this.$baseUrl +
          "/api/user/user_log?user_token=" +
          this.$storage.get("token"),
        qs.stringify({ page: 1, type: this.show })
      )
      .then(res => {
        if (res.data.data) {
          let data = res.data.data;
          this.list = data.list;
          this.total = parseInt(data.count);
        } else {
          this.list = [];
          this.total = 0;
        }
      })
      .catch();
  },
  data() {
    return {
      show: 1,
      list: [],
      page: 1,
      currentPage: 1,
      total: 0
    };
  }
};
</script>

<style lang="less" scoped>
.title-list {
  width: 3rem;
  height: 0.3rem;
  border-radius: 0.03rem;
  border: 1px solid #979797;
  margin: 0.2rem auto;
  display: flex;
  line-height: 0.3rem;
  text-align: center;
  border-right: 0;
  li {
    border-right: 1px solid #979797;
    flex: 1;
  }
}
.active {
  background: #5079ff;
  color: #fff;
}
.listGroup {
  font-size: 0.14rem;
  height: 6rem;
  .list {
    height: 0.6rem;
    padding: 0 0.16rem;
    box-sizing: border-box;
    display: flex;
    flex-direction: row;
    background: #fff;

    color: #666666;
    align-items: center;
    .list-left {
      flex: 1;
      .time {
        font-size: 0.12rem;
        margin-top: 0.05rem;
      }
    }
    .list-right {
      width: 1rem;
      text-align: right;
    }
  }
}
.page {
  margin: 0.2rem 0;
}
</style>
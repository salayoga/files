<template>
  <div class="register">
    <van-nav-bar left-text="注册" left-arrow @click-left="onClickLeft" />
    <img class="img" :src="require('@/assets/images/logo_zhuce@2x.png')" alt />
    <div class="container">
      <div class="form">
        <my-select :selectList="countryList" @funcSelect="handleChangeSelect">
          <option value disabled hidden selected>请选择国籍</option>
        </my-select>
        <my-input :placeholder="'请输入昵称'" :label="'昵称'" v-model="username"></my-input>
        <my-input :placeholder="'请输入手机号码作为注册账号'" :label="'手机号码'" v-model="phone"></my-input>
        <my-input :placeholder="'请输入验证码'" :label="'验证码'" :btn="btn" :tel="phone" v-model="code"></my-input>
        <my-input
          :placeholder="'请输入登录密码'"
          :label="'登录密码'"
          :inputtype="'password'"
          v-model="password"
        ></my-input>
        <my-input
          :placeholder="'请再次输入密码'"
          :label="'确认密码'"
          :inputtype="'password'"
          v-model="passwordAgain"
        ></my-input>
        <my-input
          :placeholder="'请输入二级密码'"
          :label="'二级密码'"
          v-model="erjiPassword"
          :inputtype="'password'"
        ></my-input>
        <my-input
          :placeholder="'请再次输入二级密码'"
          :label="'再次二级密码'"
          v-model="re_erjiPassword"
          :inputtype="'password'"
        ></my-input>

        <my-input
          :placeholder="invitePLaceholder"
          :label="'邀请码'"
          v-model="invite"
          :disabled="disabled"
        ></my-input>
      </div>
      <div class="submit">
        <van-button class="btn" type="info" @click="submit" :disabled="btnSubmit">注册</van-button>
        <router-link class="goDownload" to="/download" v-show="toDownload">已有账号去下载</router-link>
      </div>
    </div>
  </div>
</template>

<script>
import MySelect from "@/components/Select";
import MyInput from "@/components/input";
import { myCountryList } from "@/api/define";
import { checkBlank, checkPsw, checkPhone, checkName } from "@/api/form";
import qs from "qs";
export default {
  data() {
    return {
      countryList: myCountryList,
      btn: true,
      selectValue: "",
      phone: "",
      password: "",
      passwordAgain: "",
      code: "",
      username: "",
      invite: "",
      erjiPassword: "",
      re_erjiPassword: "",
      disabled: false,
      invitePLaceholder: "请输入邀请码",
      toDownload: false,
      btnSubmit: false
    };
  },
  mounted() {
    let userCode = location.href;
    let data = userCode.split("?")[1];
    let url = /user_code/.test(userCode);
    if (url) {
      this.invite = data.slice(10, 16);
      this.invitePLaceholder = data.slice(10, 16);
      this.disabled = true;
      this.toDownload = true;
    }
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    submit() {
      this.btnSubmit = true;
      setTimeout(() => {
        this.btnSubmit = false;
      }, 5000);
      if (
        checkBlank([
          this.selectValue,
          this.code,
          this.passowrd,
          this.passwordAgain,
          this.username,
          this.invite
        ]) ||
        checkPsw(this.passwordAgain, this.password) ||
        checkPhone(this.phone) ||
        checkPsw(this.re_erjiPassword, this.erjiPassword) ||
        checkName(this.username)
      ) {
        return;
      }
      this.$http
        .post(
          this.$baseUrl + "/api/public/reg",
          qs.stringify({
            username: this.username,
            password: this.password,
            re_password: this.passwordAgain,
            mobile_code: this.code,
            user_code: this.invite,
            mobile: this.phone,
            country: encodeURI(encodeURI(this.selectValue)),
            erji_password: this.erjiPassword,
            re_erji_password: this.re_erjiPassword
          })
        )
        .then(res => {
          let data = res.data;
          if (data.code == 1) {
            this.$toast(data.msg);
            if (this.toDownload) {
              this.$router.push("/download");
            } else {
              this.$router.push("/login");
            }
          } else {
            this.$toast(data.msg);
          }
        })
        .catch();
    },
    handleChangeSelect(value) {
      this.selectValue = value;
    }
  },
  components: {
    MyInput,
    MySelect
  }
};
</script>

<style lang="less" scoped>
.register {
  .img {
    display: block;
    height: 0.51rem;
    margin: 0.4rem auto;
  }
  .container {
    margin-bottom: 0.5rem;
  }
}
.goDownload {
  width: 100%;
  margin-top: 0.1rem;
  height: 44px;
  line-height: 44px;
  text-align: center;
  background: #1989fa;
  display: block;
  border-radius: 0.225rem;
  color: #fff;
}
</style>
export const myCountryList = [
  { name: "中国", value: 1 },
  { name: "中国香港", value: 2 },
  { name: "中国台湾", value: 3 },
  { name: "韩国", value: 4 },
  { name: "英国", value: 5 },
  { name: "德国", value: 6 },
  { name: "加拿大", value: 7 },
  { name: "巴西", value: 8 },
  { name: "俄罗斯", value: 9 },
  { name: "法国", value: 10 },
  { name: "菲律宾", value: 11 },
  { name: "柬埔寨", value: 12 },
  { name: "马来西亚", value: 13 },
  { name: "马尔代夫", value: 14 },
  { name: "挪威", value: 15 },
  { name: "瑞典", value: 16 },
  { name: "泰国", value: 17 },
  { name: "新加坡", value: 18 },
  { name: "印度", value: 19 },
  { name: "意大利", value: 20 },
  { name: "越南", value: 21 },
  { name: "日本", value: 22 },
  { name: "美国", value: 23 }
]

export const baseUrl = "http://qqld.vip"

const ceshi = "http://47.110.89.169"
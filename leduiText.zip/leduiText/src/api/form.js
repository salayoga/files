import Vue from 'vue'
import { Toast } from 'vant'
import store from '../store'
import Axios from 'axios'
import { baseUrl } from '@/api/define'
import qs from 'qs'
import md5 from 'md5'
const KEY1 = 'QQLD';
const KEY = 'gsadjksda';
Vue.use(Toast)
//必填信息不可为空
export const checkBlank = (dataList) => {
  let flag = false;
  dataList.map((item) => {
    if (item == '') {
      Toast("必填信息不可为空");
      flag = true;
      return;
    }
  })
  return flag;
}

//手机号格式
export const checkPhone = (data) => {
  if (!/^1(3|4|5|7|8)\d{9}$/.test(data)) {
    Toast("手机号格式不正确");
    return true;
  } else if (data.length != 11) {
    Toast("手机号长度不正确");
    return true;
  }
  return false;
}

//输入金额
export const checkMoney = (data) => {
  if (data <= 0 || data > store.state.money) {
    // Toast("请检查输入金额");
    // return true;
  }
  return false;
}

//获取短信验证码
export const getCode = (phone) => {
  if (phone == '' || checkPhone(phone)) {
    Toast("请检测你的手机号");
    return false;
  } else {
    Axios.post(baseUrl + "/api/public/get_mobile_code", qs.stringify({ mobile: phone })).then(
      res => {
        let mydata = res.data;
        console.log(mydata);
        if (mydata.code == 1) {
          Toast(mydata.msg);
        } else {
          Toast(mydata.msg);
        }
      }
    ).catch()
  }
  return true;
}

//检测密码是否合格且相等
export const checkPsw = (password, passwordAgain) => {
  if (password.length < 6 || password.length > 20 || passwordAgain.length < 6 || passwordAgain.length > 20) {
    Toast("密码应该大等于6位小等于20位");
    return true;
  } else if (password !== passwordAgain) {
    Toast("两次密码不一致,请重新输入");
    return true;
  }
  return false;
}

//检测单个密码格式
export const checkPswForm = (password) => {
  if (password.length < 6 || password.length > 20) {
    Toast("密码应该大等于6位小等于20位");
    return true;
  }
  return false;
}

export const checkName = (username) => {
  if (username.length > 12 || username.length < 6) {
    Toast("用户名必须大等于6小等于12位");
    return true;
  }
  return false;
}

export const changeParams = (data) => {
  let params = stringData(data);
  data.sign = md5(`${md5(`${params}${KEY1}`)}${KEY}`)
  return stringData(data);
}

const stringData = (data) => {
  const ordered = {};
  Object.keys(data).sort().forEach(function (key) {
    ordered[key] = data[key];
  });
  // window.console.log(qs.stringify(ordered))
  return qs.stringify(ordered)
}
<template>
  <div class="charge" v-show="order_sn">
    <div class="infoList">
      <div>接单时间 : {{createtime}}</div>
      <div>订单编号 : {{order_sn}}</div>
    </div>

    <div class="price">{{price}}</div>
  </div>
</template>

<script>
export default {
  props: {
    createtime: String,
    order_sn: String,
    price: String
  }
};
</script>

<style lang="less" scoped>
.charge {
  width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: 0.1rem 0.15rem;
  height: 0.7rem;
  border-radius: 0.1rem;
  background: #fff;
  box-sizing: border-box;
  margin-top: 0.15rem;
  .infoList {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
  }
  .price {
    font-size: 0.2rem;
    font-weight: bold;
    color: #4571ff;
  }
}
</style>
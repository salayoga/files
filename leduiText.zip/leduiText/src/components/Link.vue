<template>
  <div>
    <router-link
      :class="{'link':true,'border':border}"
      tag="div"
      :to="url"
      @click="$emit('funcLink')"
    >
      <img class="linkimg" :src="imgUrl" alt />
      <div>{{content}}</div>
    </router-link>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  props: {
    url: String,
    imgUrl: String,
    content: String,
    border: Boolean
  }
};
</script>

<style lang="less" scoped>
.link {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 0.5rem;
  border-bottom: 1px solid #eee;
  background: url(../assets/images/icon_arrow@2x.png) right center no-repeat;
  background-size: auto 0.1rem;
  .linkimg {
    width: 0.26rem;

    margin-right: 0.2rem;
  }
}
.border {
  border: none;
}
</style>
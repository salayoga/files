<template>
  <div class="mask" v-if="show">
    <div class="cover">
      <div class="title">消息</div>
      <div>是否支付矿工费</div>
      <div class="btnGroup">
        <router-link tag="button" to="/invest">充币</router-link>
        <router-link tag="button" to="/pay">确定</router-link>
      </div>
    </div>
    <div class="close" @click="$emit('funcCover')"></div>
  </div>
</template>

<script>
export default {
  props: {
    show: {
      type: Boolean,
      default: true
    }
  }
};
</script>

<style lang="less" scoped>
.mask {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 2;
  .close {
    width: 0.285rem;
    height: 0.285rem;
    background: url(../assets/images/icon_close@2x.png) no-repeat;
    background-size: 100%;
    margin-top: 0.5rem;
  }
  .cover {
    padding: 0.15rem;
    width: 2.9rem;
    height: 1.8rem;
    border-radius: 0.15rem;
    background: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    text-align: center;
    .title {
      font-size: 0.16rem;
      font-weight: bold;
    }

    .btnGroup {
      display: flex;
      justify-content: space-between;
      button {
        width: 1rem;
        height: 0.36rem;
        border-radius: 0.18rem;
        background: #4672ff;
        color: #fff;
        line-height: 0.36rem;
      }
      button:last-child {
        background: #ff9c00;
      }
    }
  }
}
</style>
<template>
  <div class="input">
    <div class="title">
      <div class="left">{{label}}</div>
      <slot></slot>
    </div>
    <div class="cover">
      <input
        :type="inputtype"
        :placeholder="placeholder"
        @input="$emit('input',$event.target.value)"
        v-model="showDefaultValue"
        :disabled="disabled"
        autocomplete="off"
      />

      <button class="btn" @click="getcode" v-if="btn" :btn="btn" :disabled="bool">{{content}}</button>
    </div>
  </div>
</template>

<script>
import { getCode } from "@/api/form";
export default {
  props: {
    label: String,
    inputtype: { type: String, default: "text" },
    placeholder: String,
    btn: { type: Boolean, default: false },
    tel: { type: String, default: "" },
    disabled: { type: Boolean, default: false }
  },
  methods: {
    getcode() {
      if (getCode(this.tel)) {
        this.bool = true;
        this.content = 60;
      }
    }
  },
  data() {
    return {
      bool: false,
      content: "获取验证码",
      showDefaultValue: ""
    };
  },
  watch: {
    content(newValue) {
      if (newValue == 60) {
        let timer = setInterval(() => {
          this.content = --newValue;
          if (this.content == 0) {
            clearInterval(timer);
            this.content = "获取验证码";
            this.bool = false;
          }
        }, 1000);
      }
    }
  }
};
</script>

<style lang="less" scoped>
.input {
  border-bottom: 1px solid #ccc;
  color: #333;
  font-size: 0.13rem;
  margin-top: 0.1rem;
  .title {
    display: flex;
    .left {
      margin-right: 0.2rem;
    }
  }
  .cover {
    display: flex;
    align-items: center;
  }
  input {
    display: block;
    height: 0.37rem;
    line-height: 0.37rem;
    width: 100%;
    color: #000;
    flex: 1;
  }
  .btn {
    padding: 0.05rem 0.12rem;
    min-width: 1rem;
    text-align: center;
    color: #fff;
    background: #1989fa;
    border-radius: 0.05rem;
  }
}
</style>
<template>
  <div>
    <div class="money-left">
      钱包余额
      <span class="remark">{{remark}}</span>
    </div>
    <div class="money">
      {{this.$store.state.money || this.$storage.get("money")}}
      <span>USDT_ERC20</span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    remark: String
  }
};
</script>

<style lang="less" scoped>
.money-left {
  margin: 0.15rem 0;
  font-size: 0.13rem;
  color: #333;
}
.money {
  font-family: SFProText-Regular;
  font-size: 0.3rem;
  color: #333;
}
.remark {
  color: #ff9c00;
}
span {
  font-size: 0.13rem;
}
</style>
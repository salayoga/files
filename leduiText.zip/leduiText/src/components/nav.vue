<template>
  <div :class="{'nav':true,'bk':show}">
    <div v-html="content"></div>
    <div v-html="message" class="right"></div>
  </div>
</template>

<script>
export default {
  props: {
    content: {
      type: String,
      default: ""
    },
    message: {
      type: String,
      default: ""
    },
    show: {
      type: Boolean,
      default: true
    }
  }
};
</script>

<style lang="less" scoped>
.nav {
  height: 0.6rem;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 100%;
  border-bottom: 1px solid #eee;
  line-height: 0.6rem;
  align-items: center;
}

.right {
  margin-right: 0.2rem;
}
</style>
<template>
  <div>
    <select class="select" v-model="selectValue" @change="handleSelect">
      <slot></slot>
      <option :value="item.value" v-for="(item,index) of selectList" :key="index">{{item.name}}</option>
    </select>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectValue: ""
    };
  },
  props: {
    placeholder: "",
    selectList: Array
  },
  created() {},
  methods: {
    handleSelect() {
      this.$emit("funcSelect", this.selectValue);
    }
  }
};
</script>

<style lang="less" scoped>
.select {
  display: block;
  width: 100%;
  border: 1px solid #999;
  border-radius: 0.05rem;
  height: 0.3rem;
  line-height: 0.3rem;
  margin-top: 0.1rem;
}
</style>
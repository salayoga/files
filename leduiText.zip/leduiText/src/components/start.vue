<template>
  <div class="swiper-top">
    <div class="swiper-top-center">
      <div>本轮公排收益</div>
      <div class="number">{{this.$store.state.gain}}%</div>
    </div>
    <router-link tag="div" to="/query" class="btn">开启</router-link>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
.swiper-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.11rem 0 0.12rem;
  .swiper-top-center {
    display: flex;
    align-items: center;
    font-family: PingFang-SC-Bold;
    font-size: 0.15rem;
    .number {
      font-size: 0.2rem;
      color: #4974ff;
      margin-left: 0.1rem;
    }
  }
  .btn {
    width: 1rem;
    height: 0.36rem;
    line-height: 0.36rem;
    text-align: center;
    background: #ff9c00;
    border-radius: 0.18rem;
    color: #fff;
  }
}
</style>
<template>
  <div>
    <div class="teamList" v-for="(item,index) of teamList" :key="index">
      <img class="img" :src="item.avatar" alt />
      <div class="right">
        <div class="right-item">
          <div>{{item.username}}</div>
          <div class="phone">{{item.mobile}}</div>
        </div>
        <div class="right-item">
          <div>
            完成接单额度:
            <span>{{item.complete}}</span> USDT_ERC20
          </div>
          <div>
            正在接单额度:
            <span>{{item.continue}}</span> USDT_ERC20
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    teamList: Array
  }
};
</script>

<style lang="less" scoped>
.teamList {
  padding: 0.2rem;
  border-radius: 0.15rem;
  background: #fff;
  height: 1.25rem;
  display: flex;
  margin-top: 0.15rem;
  .img {
    width: 0.5rem;
    height: 0.5rem;
  }
  .right {
    flex: 1;
    margin-left: 0.1rem;
    .right-item {
      height: 50%;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      font-size: 0.12rem;
      white-space: nowrap;
      .phone {
        color: #999;
      }
      span {
        color: #e93b3d;
      }
    }
    .right-item:first-child {
      border-bottom: 1px solid #999;
    }
  }
}
</style>
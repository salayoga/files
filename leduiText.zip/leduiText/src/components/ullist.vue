<template>
  <ul class="liList">
    <router-link tag="li" to="item.url" v-for="(item,index) of ulList" :key="index">
      <img :src="item.imgUrl" alt />
      <p>{{item.content}}</p>
    </router-link>
  </ul>
</template>

<script>
export default {
  data() {
    return {
      ulList: [
        {
          imgUrl: require("@/assets/images/icon_team@2x.png"),
          content: "团队",
          url: "/"
        },
        {
          imgUrl: require("@/assets/images/icon_invite@2x.png"),
          content: "邀请",
          url: "/"
        },
        {
          imgUrl: require("@/assets/images/icon_news@2x.png"),
          content: "新闻",
          url: "/"
        },
        {
          imgUrl: require("@/assets/images/icon_task@2x.png"),
          content: "任务",
          url: "/"
        }
      ]
    };
  }
};
</script>

<style>
</style>
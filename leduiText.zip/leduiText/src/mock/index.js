// import Mock from 'mockjs'

// import Main from './main'

// Mock.mock('/api/public/forgetpwd', "post", () => {

//   return Main.page1

// })

// Mock.mock('/api/public/home', "post", () => {

//   return Main.page2

// })

// Mock.mock('/api/public/invest', "post", () => {

//   return Main.page3

// })

// Mock.mock('/api/public/withdraw', "post", () => {

//   return Main.page4

// })

// Mock.mock('/api/public/get_mobile_code', "post", () => {

//   return Main.page5

// })


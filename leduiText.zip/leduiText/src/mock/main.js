const page1 = {
  code: '1',
  msg: "修改密码成功"
}

const page2 = {

  photo: require("../assets/images/userhead@2x.png"),
  name: "百里守约",
  tel: "186****1418",
  num: 278,
  liList: [
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1040",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1140",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1240",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1340",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1440",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1540",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1640",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1740",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1840",
      type: "USDT_ERC20"
    },
    {
      imgUrl: require("../assets/images/userhead@2x.png"),
      content: "138******04接单",
      money: "1940",
      type: "USDT_ERC20"
    }
  ]
}

const page3 = {
  imgUrl: require('@/assets/images/erweima@2x.png')
}

const page4 = {
  msg: '提现成功'
}

const page5 = {
  code: 1,
  msg: '获取成功',
  data: 123
}

const res = {

  page1,

  page2,

  page3,

  page4,
  page5

}

export default res;
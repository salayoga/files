import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/Pages/Home/Home'
import Charge from '@/Pages/Charge'
import Forget from '@/Pages/Forget'
import My from '@/Pages/My'
import Problem from '@/Pages/My/Problem'
import Message from '@/Pages/My/Message'
import Transfer from '@/Pages/Home/Transfer'
import Query from '@/Pages/Home/Query'
import FriendRegister from '@/Pages/My/FriendRegister'
import Info from '@/Pages/My/Info'
import Address from '@/Pages/My/Address'
import ChangePsw from '@/Pages/My/ChangePsw'
import ChangeSecondPsw from '@/Pages/My/ChangeSecondPsw'
import Invite from '@/Pages/My/Invite'
import Wallet from '@/Pages/My/Wallet'
import Invest from '@/Pages/Home/Invest'
import Withdraw from '@/Pages/Home/Withdraw'
import Team from '@/Pages/My/Team'
import Login from '@/Pages/Login'
import Register from '@/Pages/Register'
import Pay from '@/Pages/Home/Pay'
import TeamLeft from '@/Pages/My/TeamLeft'
import TeamRight from '@/Pages/My/TeamRight'
import error from '@/Pages/404'
import EditPhoto from '@/Pages/My/EditPhoto'
import EditName from '@/Pages/My/EditName'
import Notice from '@/Pages/Home/Notice'
import MessageInfo from '@/Pages/My/MessageInfo'
import Download from '@/Pages/Download'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home,
      meta: {
        isLogin: true,
        hasBottom: true,
        keepAlive: true
      }
    },
    {
      path: '/messageinfo',
      name: 'MessageInfo',
      component: MessageInfo,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: false
      }
    },
    {
      path: '/download',
      name: 'Download',
      component: Download,
      meta: {
        isLogin: false,
        hasBottom: false,
      }
    },
    {
      path: '/notice',
      name: 'Notice',
      component: Notice,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/editname',
      name: 'EditName',
      component: EditName,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/editphoto',
      name: 'EditPhoto',
      component: EditPhoto,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/pay',
      name: "Pay",
      component: Pay,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/register',
      name: 'Register',
      component: Register,
      meta: {
        isLogin: false,
        hasBottom: false
      }
    },
    {
      path: '/login',
      name: 'Login',
      component: Login,
      meta: {
        isLogin: false,
        hasBottom: false,
        keepAlive: false
      }
    },
    {
      path: '/home',
      redirect: {
        name: 'Home'
      },
      meta: {
        isLogin: true,
        hasBottom: true,
        keepAlive: true
      },
    },
    {
      path: '/invest',
      name: "Invest",
      component: Invest,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: true
      }
    },
    {
      path: '/withdraw',
      name: "Withdraw",
      component: Withdraw,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/charge',
      name: 'Charge',
      component: Charge,
      meta: {
        isLogin: true,
        hasBottom: true,
      }
    },
    {
      path: '/forget',
      name: 'Forget',
      component: Forget,
      meta: {
        isLogin: false,
        hasBottom: false
      }
    },
    {
      path: '/my',
      name: 'My',
      component: My,
      meta: {
        isLogin: true,
        hasBottom: true,
        keepAlive: true
      }
    },
    {
      path: '/team',
      name: 'Team',
      component: Team,
      redirect: '/team/teamleft',
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: false
      },
      children: [
        {
          path: '/team/teamleft', name: 'TeamLeft', component: TeamLeft, meta: {
            isLogin: true,
            hasBottom: false,
            keepAlive: false
          },
        },
        {
          path: '/team/teamright', name: 'TeamRight', component: TeamRight, meta: {
            isLogin: true,
            hasBottom: false,
            keepAlive: false
          },
        },
      ]
    },
    {
      path: '/problem',
      name: 'Problem',
      component: Problem,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: false
      }
    },
    {
      path: '/message',
      name: 'Message',
      component: Message,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: false
      }
    },
    {
      path: '/transfer',
      name: "Transfer",
      component: Transfer,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: false
      }
    },
    {
      path: '/query',
      name: 'Query',
      component: Query,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/friendregister',
      name: 'FriendRegister',
      component: FriendRegister,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/info',
      name: Info,
      component: Info,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: true
      }
    },
    {
      path: '/address',
      name: "Address",
      component: Address,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    }
    , {
      path: '/changepsw',
      name: "ChangePsw",
      component: ChangePsw,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/changesecondpsw',
      name: "ChangeSecondPsw",
      component: ChangeSecondPsw,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/invite',
      name: 'Invite',
      component: Invite,
      meta: {
        isLogin: true,
        hasBottom: false,
        keepAlive: true
      }
    },
    {
      path: '/wallet',
      name: 'Wallet',
      component: Wallet,
      meta: {
        isLogin: true,
        hasBottom: false
      }
    },
    {
      path: '/404',
      name: 'error',
      component: error,
      meta: {
        isLogin: false,
        hasBottom: false
      }
    },
    {
      path: '*',
      redirect: '/404',
    }
  ],
})

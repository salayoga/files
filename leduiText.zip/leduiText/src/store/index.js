import Vue from 'vue' // 引入vue
import Vuex from 'vuex' // 引入vuex
import Storage from '@/api/Storage'

// 使用vuex
Vue.use(Vuex)




// 创建Vuex实例
const Store = new Vuex.Store({

  // 设置属性
  state: {
    isLogin: false,
    acount: [], // 查询到的账号
    money: 0,
    num: 0,
    token: '',
    zt: 0,
    allt: 0,
    status: false,
    name: '',
    photo: '',
    phone: "",
    active: 'home',
    address: "",
    gain: 0,
    showStatus: false

  },

  // 获取属性的状态
  getters: {
    //获取登录状态
    isLogin: state => state.isLogin,



    //获取token方法
    //判断是否有token,如果没有重新赋值，返回给state的token
    getToken(state) {
      if (!state.token) {
        state.token = localStorage.getItem('token')
      }
      return state.token
    }
  },

  // 设置属性状态
  mutations: {
    //保存登录状态
    userStatus(state, flag) {
      state.isLogin = flag
    },
    changeMoney(state, money) {
      state.money = Math.floor(Number(money * 100)) / 100;
      Storage.set("money", money);
    },
    changeNum(state, num) {
      state.num = num
    },
    changezt(state, zt) {
      state.zt = zt;
    },
    changeallt(state, allt) {
      state.allt = allt;
    },
    changeStatus(state, status) {
      if (status == '0') {
        status = true;
      } else {
        status = false;
      }
      state.status = status;

    },
    changeName(state, name) {
      state.name = name;
      Storage.set("name", name);
    },
    changePhone(state, phone) {
      state.phone = phone;
      Storage.set("phone", phone);
    },
    changePhoto(state, photo) {
      state.photo = photo;
      Storage.set("photo", photo);
    },
    changeActive(state, active) {
      state.active = active;
      Storage.set("active", active);
    }, changeAddress(state, address) {
      state.address = address;
      Storage.set("address", address);
    },
    changeGain(state, gain) {
      state.gain = gain;
      Storage.set("gain", gain);
    },
    changeShowStatus(state, showStatus) {
      state.showStatus = showStatus;
      Storage.set("showStatus", showStatus);
    }
  },

  // 应用mutations
  actions: {
    //获取登录状态
    userLogin({ commit }, flag) {
      commit("userStatus", flag)
    },
  }

})

export default Store // 导出store